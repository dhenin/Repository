javac *.java;
java Quizz

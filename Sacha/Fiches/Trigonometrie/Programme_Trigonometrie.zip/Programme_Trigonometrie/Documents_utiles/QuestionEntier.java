  // Dans ce cas, la réponse est un entier... C'est-à-dire exactementcomme pour un réel
  // sauf la définition

  public class QuestionEntier extends QuestionReel{

    public QuestionEntier(String enonce, int reponse, double score){
      super(enonce, reponse, score);
    }

  }
